# RISC-V Morse Code Translator

## Overview

A Morse-code translator implemented in **RISC-V assembly**. The program reads an ASCII input string, converts each uppercase character to an index, looks up a pre-encoded Morse representation, and drives an LED with the corresponding timed output pattern.

Rather than storing Morse strings, the implementation represents each letter as a compact **16-bit pattern** in a lookup table. This makes the project a useful exercise in data representation, pointer arithmetic, memory addressing, bit manipulation, subroutine design, and direct GPIO control.

## How It Works

1. An input string is stored as a null-terminated ASCII sequence.
2. Each character is loaded with `lbu`.
3. `'A'` (`0x41`) is subtracted from the ASCII value to obtain an alphabet index.
4. The index is scaled to address the corresponding 16-bit entry in `MorseLUT`.
5. The encoded Morse pattern is loaded with `lhu`.
6. The pattern is shifted and decoded bit-by-bit.
7. LED ON/OFF subroutines write directly to the memory-mapped GPIO output register.
8. Delay subroutines create intra-symbol, inter-character, and inter-word timing.

## Technical Highlights

- RISC-V assembly programming
- ASCII-to-index conversion
- 16-bit Morse-code lookup table
- Pointer arithmetic and indexed memory access
- Bit shifting and sign-bit testing
- Stack usage and return-address preservation
- Memory-mapped GPIO output
- Reusable `LED_ON`, `LED_OFF`, and `DELAY` subroutines

## Why This Project Matters

The project demonstrates how higher-level concepts such as character translation and signal sequencing are implemented directly at the machine level. It required explicit control over memory, registers, control flow, timing, and physical I/O—skills that transfer directly to firmware and embedded controls development.

## Suggested Portfolio Media

Add one or two items here before sharing with recruiters:

- Photo/video of the LED producing a Morse sequence
- Screenshot of the `MorseLUT` and `CHAR2MORSE` routine
- Small diagram: `ASCII Input → LUT Index → Encoded Pattern → GPIO LED`

## Source

[`src/morse_code_translator.S`](./src/morse_code_translator.S)
