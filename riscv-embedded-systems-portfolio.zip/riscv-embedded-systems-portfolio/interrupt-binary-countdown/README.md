# RISC-V Interrupt-Driven Binary Countdown Timer

## Overview

An interrupt-driven countdown system implemented in **RISC-V assembly**. The main program flashes an LED bar, while a pushbutton falling edge triggers a machine external interrupt. The interrupt service routine generates a pseudo-random countdown value, displays it in binary on an 8-LED bar, decrements it once per second, and then safely returns to the interrupted program.

This project goes beyond a polling-based timer by configuring the RISC-V interrupt path directly, including machine CSRs, GPIO interrupt registers, and the Platform-Level Interrupt Controller (PLIC).

## How It Works

1. `mtvec` is configured with the address of the pushbutton ISR.
2. Machine external interrupts are enabled through `mie` and global interrupts through `mstatus`.
3. GPIO falling-edge interrupt detection is enabled for the pushbutton.
4. The corresponding PLIC source is enabled and assigned a high priority.
5. The main loop continuously flashes the LED bar and advances a pseudo-random generator.
6. Pressing the button causes the CPU to enter `S1_interrupt`.
7. The ISR saves its working register context to the stack and claims the interrupt from the PLIC.
8. A pseudo-random value is scaled to a countdown range.
9. `Display_Num` maps the binary value onto the physical LED-bar GPIO pins.
10. The value is decremented once per second until it reaches zero.
11. The ISR completes the PLIC interrupt, clears the GPIO pending state, restores registers, and returns with `mret`.

## Technical Highlights

- RISC-V machine-mode interrupt configuration
- `mtvec`, `mie`, and `mstatus` CSR manipulation
- Platform-Level Interrupt Controller (PLIC) configuration
- GPIO falling-edge interrupts
- Interrupt service routine design
- Explicit register context save/restore using the stack
- Memory-mapped GPIO I/O
- Binary-to-LED pin mapping
- Pseudo-random value generation using bit operations
- Deterministic software timing loops

## Controls / Firmware Relevance

This project demonstrates event-driven embedded control rather than simple sequential polling. It combines hardware interrupts, state preservation, deterministic output updates, physical I/O, and low-level processor configuration—the same underlying concepts used in real-time firmware and industrial control systems.

## Suggested Portfolio Media

Add one or two items here before sharing with recruiters:

- Photo/video of the LED bar counting down in binary
- Screenshot highlighting the ISR and PLIC configuration
- Diagram: `Pushbutton → GPIO Interrupt → PLIC → ISR → Binary LED Output`

## Source

[`src/interrupt_binary_countdown.S`](./src/interrupt_binary_countdown.S)
